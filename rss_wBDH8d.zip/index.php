<?php
error_reporting(E_ALL || ~E_NOTICE);
header("Content-type: text/xml");
$domainName = "https://acgf.me";
$m_domainName = "https://m.acgf.me";
$response = geturl($domainName."/api/v2/animates?sortBy=updatedAt&sortOrder=-1&size=20&page=1");
//$response_json = json_decode($response);
$arrlength = count($response['data']['list']);

$return = '<?xml version="1.0" encoding="UTF-8"?><rss version="2.0"
	xmlns:content="http://purl.org/rss/1.0/modules/content/"
	xmlns:wfw="http://wellformedweb.org/CommentAPI/"
	xmlns:dc="http://purl.org/dc/elements/1.1/"
	xmlns:atom="http://www.w3.org/2005/Atom"
	xmlns:sy="http://purl.org/rss/1.0/modules/syndication/"
	xmlns:slash="http://purl.org/rss/1.0/modules/slash/"
	
xmlns:georss="http://www.georss.org/georss" xmlns:geo="http://www.w3.org/2003/01/geo/wgs84_pos#"
>

<channel>
	<title>ACGF次元幻想番剧更新订阅</title>
	<atom:link href="https://rss.acgf.me" rel="self" type="application/rss+xml" />
	<link>https://acgf.me</link>
	<description>ACGF次元幻想</description>
	<language>zh-CN</language>
';
for($x=0;$x<$arrlength;$x++)
{
	$p=$response['data']['list'][$x]['coverVertical'];
	if($p!=""){
	    if(strstr($p,"http")=="")$pic = '<img src="'.$domainName.$p.'">';
	    else $pic = '<img src="'.$p.'">';
	}
	else $pic = "";
	if($response['data']['list'][$x]['lastEposide']['title']!=""){
		$lastEposide = $response['data']['list'][$x]['lastEposide']['_id'];
		$lastE = "<br>已更新至".$response['data']['list'][$x]['lastEposide']['title']."<br>未找到想看动漫，请前往网站申请番剧";
	}
	else $lastEposide = "";
	
	$return = $return.PHP_EOL."<item>";
    $return = $return.PHP_EOL."<title>".$response['data']['list'][$x]['title']."</title>";
	$return = $return.PHP_EOL."<description><![CDATA[".$response['data']['list'][$x]['introduce'].PHP_EOL.$lastE.PHP_EOL.$pic."]]></description>";
	$return = $return.PHP_EOL."<link>".$domainName."/animate/slug/".$response['data']['list'][$x]['slug']."</link>";
	$return = $return.PHP_EOL."<pubDate>".$response['data']['list'][$x]['updatedAt']."</pubDate>";
	$return = $return.PHP_EOL."</item>";
}

$return = $return. PHP_EOL .'</channel>
</rss>';
echo $return;


//echo count($response['data']['list']);
function posturl($url,$data){
        //$data  = json_encode($data);    
        $headerArray =array();
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,FALSE);
        curl_setopt($curl,  CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        curl_setopt($curl,CURLOPT_HTTPHEADER,$headerArray);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $output = curl_exec($curl);
		//var_dump($output);
        curl_close($curl);
        return $output;
}
function geturl($url){
        $headerArray =array("Content-type:application/json;","Accept-Encoding:gzip, deflate, br;","Accept:application/json, text/javascript, */*; q=0.01","User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.25 Safari/537.36 Core/1.70.3775.400 QQBrowser/10.6.4209.400;");
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE); 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch,CURLOPT_HTTPHEADER,$headerArray);
		//var_dump($output);
        $output = curl_exec($ch);
        curl_close($ch);
        $output = json_decode($output,true);
        return $output;
}
function get_between($input, $start, $end) {        //文本_取中间
  $substr = substr($input, strlen($start)+strpos($input, $start),
 (strlen($input) - strpos($input, $end))*(-1));
  return $substr; 
}
?>